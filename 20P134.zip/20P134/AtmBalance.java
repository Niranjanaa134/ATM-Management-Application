package assignment;

public class AtmBalance {
	int balance;
	int withdraw;
	int deposit;
	AtmBalance(){
		
	}
	AtmBalance(int balance,int withdraw,int deposit){
		this.balance=balance;
		this.withdraw=withdraw;
		this.deposit=deposit;
	}
	public void setBalance(int balance){
		this.balance=balance;
	}
	public int getBalance(){
		return balance;
	}

	public void setWithdraw(int withdraw){
		this.withdraw=withdraw;
	}
	public int getWithdraw(){
		return withdraw;
	}

	public void setDeposit(int deposit){
		this.deposit=deposit;
	}
	public int getDeposit(){
		return deposit;
	}
}
