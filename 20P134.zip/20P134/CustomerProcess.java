package assignment;
import java.util.TreeMap;
public class CustomerProcess {
public void transferAmount(String fromAccNo,String toAccNo,int amount,TreeMap<String,CustomerDetails> cd){
	cd.get(fromAccNo).Withdraw(fromAccNo, amount, cd);
	cd.get(toAccNo).Deposit(toAccNo, amount, cd);
}
}
