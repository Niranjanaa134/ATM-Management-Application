package assignment;

public class AtmProcess {
	public static void updateDenomination(int amount, int denomination,LoadAtm la){
        if(amount==2000){
                la.setTwoThousand(la.getTwoThousand()+denomination);
        }
        else if(amount==500){
                la.setFiveHundred(la.getFiveHundred()+denomination);
        }
        else if(amount==100){
                la.setOneHundred(la.getOneHundred()+denomination);
        }
    }

    public static int reduceDenomination(int amount, int denomination, LoadAtm la){
        int flag1=0, flag2=0;
        if(amount==2000){
            if(la.getTwoThousand()>0){
                la.setTwoThousand(la.getTwoThousand()-denomination);
                return 1;
            }
            else if(la.getFiveHundred()>0){
                flag1=1;
                la.setFiveHundred(la.getFiveHundred()-denomination);
            }
            else if(la.getOneHundred()>0){
                flag2=1;
                la.setOneHundred(la.getOneHundred()-denomination);
            }
        }
        else if(amount==500){
            if(la.getFiveHundred()>0){
                if(flag1==0){
                   la.setFiveHundred(la.getFiveHundred()-denomination);
                    return 1;
                }
            }
            else if(la.getOneHundred()>0)
                if(flag2==0)
                la.setOneHundred(la.getOneHundred()-denomination);
        }
        else if(amount==100){
            if(la.getOneHundred()>0){
                if(flag2==0){
                la.setOneHundred(la.getOneHundred()-denomination);
                return 1;}
            }
        }
        return -1;
    }

    public static void updateDepositingAmount(AtmBalance ab,LoadAtm la){
        int depositAmount=la.getTwoThousand()*2000+la.getFiveHundred()*500+la.getOneHundred()*100;
       ab.setDeposit(depositAmount);
        ab.setBalance(ab.getDeposit());
    }

    public static void updateWithdraw(AtmBalance ab, int withdrawAmount){
        ab.setWithdraw(withdrawAmount);
        ab.setBalance(ab.getBalance()-withdrawAmount);
    }

    public static int[] dispensingDenomination(int[] notes, int withdrawAmount){
        int[] noteCounter=new int[notes.length];
        for(int i=0;i<notes.length;i++){
            if(withdrawAmount>=notes[i]){
                noteCounter[i]=withdrawAmount/notes[i];
                withdrawAmount=withdrawAmount-noteCounter[i]*notes[i];
            }
        }
        return noteCounter;
    }
}
