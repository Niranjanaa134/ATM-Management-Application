package assignment;
import java.util.TreeMap;
public class CustomerDetails {
String accountNo;
String Name;
String pinNo;
int accBalance;
CustomerDetails(String accountNo,String Name,String pinNo,int accBalance){
	this.accountNo=accountNo;
	this.Name=Name;
	this.pinNo=pinNo;
	this.accBalance=accBalance;
}
public void setAccountNo(String accountNo){
	this.accountNo=accountNo;
}
public String getAccountNo(){
	return accountNo;
}

public void setName(String name){
	this.Name=name;
}
public String getName(){
	return Name;
}

public void setPinNo(String pinNo){
	this.pinNo=pinNo;
}
public String getPinNo(){
	return pinNo;
}

public void setAccBalance(int accBalance){
	this.accBalance=accBalance;
}
public int getAccBalance(){
	return accBalance;
}

public void Withdraw(String accountNo,int amount,TreeMap<String,CustomerDetails> cd){
	cd.get(accountNo).setAccBalance(getAccBalance()-amount);
}
public void Deposit(String accountNo,int amount,TreeMap<String,CustomerDetails> cd){
	cd.get(accountNo).setAccBalance(getAccBalance()+amount);
}

}
