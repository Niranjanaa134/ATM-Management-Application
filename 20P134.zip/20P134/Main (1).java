package assignment;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) {
        try(Scanner scanner=new Scanner(System.in);) {
            AtmBalance ab=new AtmBalance();
            AtmProcess ap=new  AtmProcess();
            CustomerProcess cp=new CustomerProcess();

            TreeMap<String, CustomerDetails> db=new TreeMap<>();
            int[] notes=new int[]{2000, 500, 100};
            LoadAtm la=new LoadAtm();
            System.out.println("\t\tCustomer Bank Details & ATM Process");
            
            while (true){
                int option=0;
                System.out.println("\n\n\tChoose an Option from below ....\n1. Load ATM\n2. Withdraw amount From ATM\n3. Check ATM Balance\n4. Create Account\n5. Transfer amount\n6. Check Account Balance of a person\n7. Display all Customer Details\n8. Deposit amount\n9. End");
                option=scanner.nextInt();
                System.out.println();
                scanner.nextLine();
                switch (option){
                    case 1:
                    {
                        System.out.println("        --------    Load ATM    --------");
                        System.out.println("Enter the Denomination to deposit(2000:value, 500:value ,100:value) : ");
                        String[] denominations=scanner.nextLine().split(",");
                        int flag=1;
                        for(String seperate:denominations){
                            String[] values=seperate.split(":");
                            int amount=Integer.valueOf(values[0].trim());
                            int denomination=Integer.valueOf(values[1]);
                            if(amount<0||denomination<0){
                                System.out.println("Incorrect Deposit amount");
                            }
                            else if (amount==0||denomination==0){
                                System.out.println("Deposit amount cannot be Zero");
                            }
                            else{
                                ap.updateDenomination(amount, denomination, la);
                            }
                        }

                            ap.updateDepositingAmount(ab, la);


                        System.out.println("Denomination            Number  Value       ");
                        System.out.println("--------------------------------------------");
                        System.out.println("2000                    "+la.getTwoThousand()+"       "+2000*la.getTwoThousand());
                        System.out.println("500                     "+la.getFiveHundred()+"       "+500*la.getFiveHundred());
                        System.out.println("100                     "+la.getOneHundred()+"       "+100*la.getOneHundred());
                        break;
                    }
                    case 2:
                    { 
                    	try{
                        System.out.println("            -------- Withdraw --------");

                        System.out.println("Enter the Account Number : ");
                        String accountNumber=scanner.next();
                        System.out.println("Enter the Pin Number : ");
                        String pinNumber=scanner.next();
                      
                            System.out.println("Enter the amount to Withdraw : ");
                            int withdrawAmount=scanner.nextInt();
                            if(withdrawAmount<=0||withdrawAmount>ab.getBalance()){
                                System.out.println("No amount in ATM :(");break;
                            }
                            else if(db.get(accountNumber).getAccBalance()>1000&&db.get(accountNumber).getAccBalance()<100){
                                System.out.println("Withdraw Amount should be 100<amount<1000");break;
                            }
                            db.get(accountNumber).Withdraw(accountNumber, withdrawAmount, db);
                            int flag=1;
                            int[] dispensingDenominations=ap.dispensingDenomination(notes, withdrawAmount);
                            for(int i=0;i< notes.length;i++){
                                if(dispensingDenominations[i]>0){
                                    flag=ap.reduceDenomination(notes[i], dispensingDenominations[i], la);
                                }
                            }
                            System.out.println();
                            if(flag==1)
                                ap.updateWithdraw(ab, withdrawAmount);
                            else {
                                System.out.println("No Denomination Available :(");
                                break;
                            }
                     }
                    	catch(Exception e){
                    		System.out.println(e);
                    		System.out.println("Check your account number or pin number:(");  
                    	}
                    	   break;
                    }
                    case 3:
                    {
                        int currentAtmBalance=ab.getBalance();
                        if(currentAtmBalance<=0){
                            System.out.println("No balance  in ATM .Kindly refill it!!");
                            continue;
                        }
                        else{
                            System.out.println("        -------- Current ATM Balance --------");
                            System.out.println("Denomination            Number  Value       ");
                            System.out.println("2000                    "+la.getTwoThousand()+"       "+2000*la.getTwoThousand());
                            System.out.println("500                     "+la.getFiveHundred()+"       "+500*la.getFiveHundred());
                            System.out.println("100                     "+la.getOneHundred()+"       "+100*la.getOneHundred());
                            System.out.println("\nTotal Amount available in ATM is Rs. "+ab.getBalance());
                        }
                        break;
                    }
                    case 4:
                    {
                        System.out.println("               -------- Create Savings Account -------- ");
                        System.out.println("Enter the New Account Number : ");
                        String accountNumber=scanner.nextLine();
                        System.out.println("Enter the Customer Name : ");
                        String customerName=scanner.nextLine();
                        System.out.println("Enter the New Pin Number : ");
                        String pinNumber=scanner.nextLine();
                        System.out.println("Enter the Amount to Deposit : ");
                        int acoountBalance=scanner.nextInt();
                        if(acoountBalance>=500){
                            CustomerDetails customerDatabase=new CustomerDetails(accountNumber,customerName, pinNumber, acoountBalance);
                            db.put(accountNumber, customerDatabase);
                            System.out.println("\nSuccessfully created and deposited :)");
                        }
                        else{
                            System.out.println("Minimum balance must be >=500!!");
                            break;
                        }
                        break;
                    }
                    case 5:
                    {
                    	try{
                        System.out.println("          --------    Money Transfer    --------");

                        System.out.println("Enter your Account Number : ");
                        String fromAccountNumber=scanner.next();
                        System.out.println("Enter the Pin Number : ");
                        String fromPinNumber=scanner.next();
                       
                            System.out.println("Enter the Account Number to make Transfer : ");
                            String toAccountNumber=scanner.next();
                            System.out.println("Enter the Amount to Transfer : ");
                            int transferAmount=scanner.nextInt();
                            cp.transferAmount(fromAccountNumber, toAccountNumber, transferAmount, db);
                            System.out.println("\nSuccessfully transfered:)");
                        
                    	}
                    	catch(Exception e){
                    		System.out.println(e);
                    	}
                        break;
                    }
                    case 6:
                    {
                    	try{
                        System.out.println("--------    Check Account Balance    --------");

                        System.out.println("Enter the Account Number : ");
                        String accountNumber=scanner.next();
                        System.out.println("Enter the Pin Number : ");
                        String pinNumber=scanner.next();
                            System.out.println("AccNo  AccountHolder    PinNumber AccountBalance");
                            System.out.println("------------------------------------------------");
                            System.out.println(accountNumber+"        "+db.get(accountNumber).getName()+"        "+pinNumber+"        "+db.get(accountNumber).getAccBalance());
                        
                    	}
                    	catch(Exception e){
                    		System.out.println(e);
                    	}
                        break;
                    }
                    case 7:
                    {
                        System.out.println("          -------- Customer Details ---------");
                        System.out.println("AccNo    Account Holder    Pin Number    Account Balance");
                        System.out.println("--------------------------------------------------------");
                        for(Map.Entry<String, CustomerDetails> entry: db.entrySet()){
                            System.out.println(entry.getValue().getAccountNo()+"       "+entry.getValue().getName()+"        "+entry.getValue().getPinNo()+"        "+entry.getValue().getAccBalance());
                           
                        }
                        System.out.println("--------------------------------------------------------");
                        System.out.println();
                        break;
                    }
                    case 8:
                    {
                    	try{
                        System.out.println("-------- Deposit --------");
                        System.out.println("Enter the Account Number : ");
                        String accountNumber=scanner.next();
                       
                            System.out.println("Enter the Amount to Deposit : ");
                            int depositAmount=scanner.nextInt();
                            db.get(accountNumber).Deposit(accountNumber, depositAmount, db);
                            System.out.println("Successfully deposited:)\n");
                            System.out.println("Your Current Account Balance is Rs. "+db.get(accountNumber).getAccBalance());
                       
                    	}
                    	catch(Exception e){
                    		System.out.println(e);
                    		System.out.println("Check your account number :(");
                    	}
                    	break;
                    }
                    case 9:
                    {
                        System.out.println("\nSuccessfully completed the proces :)");
                        System.exit(0);
                    }
                    default:
                    {
                        System.out.println("Please Enter valid option :(");
                    }
                }
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }


}
